/* QR SDK smoke test: encodes one worst-case-length payload and draws it. Build it into a copy of
 * your project (replace main.c), run the ROM, and scan/decode the screen. If the decoded text
 * matches PAYLOAD below byte for byte, your encoder + renderer + toolchain setup are good.
 * See INTEGRATION_GUIDE.md "Verify your setup". */
#include "ngpc_hw.h"
#include "carthdr.h"
#include "ngpc_sys.h"
#include "ngpc_gfx.h"
#include "ngpc_timing.h"
#include "ngpc_qr.h"
#include "ngpc_qr_pixel.h"

#define QR_TILE_BASE 132u   /* first free tile slot (>= 128 keeps the BIOS font intact) */
#define QR_PAL         6u

/* 154 characters = NGPC_QR_TEXT_MAX for profile 5: the densest code this SDK can produce. */
static const char PAYLOAD[] =
    "NGPC-DEV.COM/XX/XXAAA0123456789BCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789ABCDEFGHIJ0123";

static NgpcQr s_qr;   /* static: no heap, ~230 bytes of RAM */

void main(void)
{
    ngpc_init();
    ngpc_gfx_clear(GFX_SCR1);
    ngpc_gfx_clear(GFX_SCR2);
    ngpc_gfx_set_bg_color(0x0000u);      /* black backdrop around the code */
    /* ENCODE FIRST, then draw -- never encode after drawing in the same tick. */
    if (ngpc_qr_encode(&s_qr, PAYLOAD)) {
        ngpc_qr_pixel_draw(&s_qr, GFX_SCR2, QR_TILE_BASE, QR_PAL,
                           NGPC_QR_PIXEL_SCALE, 12u, 8u);   /* (160 - 135) / 2, just under row 0 */
    }
    for (;;) ngpc_vsync();
}
