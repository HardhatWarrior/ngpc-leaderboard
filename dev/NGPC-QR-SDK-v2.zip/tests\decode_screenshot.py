"""Decode a QR code from a screenshot or photo with an independent decoder (zbar).

    pip install pillow pyzbar
    py decode_screenshot.py screenshot.png                 # print what the code says
    py decode_screenshot.py screenshot.png "EXPECTED TEXT"  # also compare byte for byte

Emulator screenshots are 160x152; the script retries at 2x-4x nearest-neighbour upscales, which
also helps with small photos. Exit status 0 = decoded (and matched, if you gave expected text).
"""
import sys
from PIL import Image
from pyzbar.pyzbar import decode

if len(sys.argv) < 2:
    sys.exit(__doc__)
img = Image.open(sys.argv[1]).convert('RGB')
expected = sys.argv[2] if len(sys.argv) > 2 else None
for scale in (1, 2, 3, 4):
    big = img.resize((img.width * scale, img.height * scale), Image.NEAREST)
    found = decode(big)
    if found:
        text = found[0].data.decode('ascii', 'replace')
        print(f'decoded {len(text)} characters (upscale {scale}x):')
        print(text)
        if expected is not None:
            if text == expected:
                print('MATCH')
            else:
                print('MISMATCH\n expected:', expected)
                sys.exit(1)
        sys.exit(0)
print('NO QR CODE FOUND (if this is an emulator screenshot, run at least 250 frames first)')
sys.exit(2)
