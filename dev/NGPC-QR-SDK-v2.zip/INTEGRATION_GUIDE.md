# NGPC Leaderboard QR SDK v2 — Integration Guide

This package lets a Neo Geo Pocket Color game put a **QR code on screen that a player scans with a
phone to submit their score** to the leaderboard at https://www.ngpc-dev.com. It is the same code
that ships in Neo Bowling and Carcassonne2 (QR *profile 5*, drawn in pixel mode).

You only build the **device side**: payload design, encoding, drawing the code. You do **not** build
or host a website. Once your payload is final you send the site owner a small spec
(`SUBMISSION_TEMPLATE.md` / `submission-template.json`) and they create your leaderboard page.

> **Coming from SDK v1?** The API changed and v1 code will not link against v2. See
> [Migrating from v1](#migrating-from-v1) at the end.

---

## What's in the package

```
src/ngpc_qr.c, ngpc_qr.h          the encoder (drop in as-is — byte-identical to the shipped games)
src/ngpc_qr_config.h              compile-time profile (default: profile 5)
src/ngpc_qr_tables.h              generated lookup tables for all profiles
src/ngpc_qr_pixel.c, .h           the renderer: draws a code on screen in pixel mode (NEW in v2)
src/example_qr_submit.c           worked example: payload builder + show screen (copy pieces from it)
tests/qr_smoke_main.c             a ROM main that draws a worst-case 154-character code
tests/expected_smoke_screen.png   what that ROM's screen looks like (decodes to the payload)
tests/expected_example_screen.png what the worked example's screen looks like
tests/decode_screenshot.py        decodes a screenshot with an independent QR decoder
SUBMISSION_TEMPLATE.md            the spec you send the site owner (human-readable form)
submission-template.json          the same form as a file the site's /dev/submit/ page can import
```

Requires **NgpCraft_base_template** (MIT) for `ngpc_gfx.h`, `ngpc_hw.h`, `ngpc_text.h` — you already
have these if your game builds with that template — and the Toshiba toolchain it uses (cc900).

---

## The pipeline in one minute

1. Game over (or wherever it makes sense) → offer "submit score".
2. Player enters 3 initials (or your game's name field).
3. Your code packs the score data into a short **payload** string and prepends the site URL prefix.
4. `ngpc_qr_encode()` turns that text into a QR matrix; `ngpc_qr_pixel_draw()` puts it on screen.
5. Player scans it with the phone's normal camera. The phone opens
   `https://NGPC-DEV.COM/<CODE>/<payload>`; the site routes that to your game's leaderboard page,
   shows the decoded result and asks the player to confirm and sign in.
6. The leaderboard page parses your payload using the spec **you** supplied.

---

## Step 1 — Verify your setup first (10 minutes, recommended)

Before designing anything, prove the encoder, renderer and your toolchain work together.

1. Copy the six `src/ngpc_qr*` files (not `example_qr_submit.c`) into your project's `src/core/`.
2. Add them to the Makefile `OBJS` list, plus header-dependency lines (cc900 emits no `.d` files, so
   a header change only rebuilds what you list):

   ```make
   OBJS += $(OBJ_DIR)/src/core/ngpc_qr.rel
   OBJS += $(OBJ_DIR)/src/core/ngpc_qr_pixel.rel

   $(OBJ_DIR)/src/core/ngpc_qr.rel: src/core/ngpc_qr.h src/core/ngpc_qr_config.h src/core/ngpc_qr_tables.h
   $(OBJ_DIR)/src/core/ngpc_qr_pixel.rel: src/core/ngpc_qr.h src/core/ngpc_qr_config.h src/core/ngpc_qr_pixel.h
   ```
3. Build a throwaway copy of your project with `tests/qr_smoke_main.c` as `main.c`.
4. Run it in an emulator for **at least 250 frames** (the encode alone takes well over a second of
   real time — a screenshot at 30 frames shows a blank screen, which is *not* a bug), take a
   screenshot, and decode it:

   ```
   py tests/decode_screenshot.py screenshot.png
   ```

   (needs `pip install pillow pyzbar`; any phone camera works too). You should get the 154-character
   text back exactly. `tests/expected_smoke_screen.png` shows what the screen should look like.

If that works, everything below will too.

---

## Step 2 — Pick a game code (2–6 characters)

Every payload starts with a short code (digits and capital letters) so the site can route a scan to the
right game. Two characters is the convention and leaves the most room for your fields. It must not
equal, prefix, or extend a code already claimed. Claimed as of this release:

| Code | Game | Code | Game |
|---|---|---|---|
| `2K` | 2048 | `OV` | Over Rev |
| `BK` | Breakout | `RD` | RED DRAGON |
| `BW` | Neo Bowling | `RVNG` | Fruity Pals' Revenge |
| `CA` | Carcassonne | `SD` | Sudoku |
| `DDMR` | Don't Die Mr Robot | `SK` | Sokoban |
| `FK` | Farkle | `TT` | Tetris |
| `FU` | Furry | `XN` | Xenon 2 |
| `GD` | Gardenia | `YZ` | Neo Yahtzee |
| `HGS` | Horatio Goes Snowboarding | `MS` | Minesweeper |

Your code, lowercased, becomes your leaderboard's folder: code `XX` → `https://www.ngpc-dev.com/xx/`.
(Over Rev is the one exception — its folder is `overrev`, set by the site owner.) Ask the site owner to
confirm your code is free before you ship.

---

## Step 3 — Design the payload

The QR carries **one string**: `URL_PREFIX + payload`.

```
NGPC-DEV.COM/XX/XXAAA12345042
'-------------''-'
 URL prefix     payload = game code + fields
```

- The prefix `NGPC-DEV.COM/<CODE>/` is what lets a phone's own camera app open the site. It is
  uppercase because QR alphanumeric mode (the smallest, most scannable encoding) has no lowercase.
  The site's 404 page lowercases the first path segment and forwards to `/xx/#<payload>`.
- The payload repeats the game code first so your page can identify and slice it.
- **Total length ≤ 154 characters** (`NGPC_QR_TEXT_MAX`) in the *worst case*, prefix included. With a
  2-character code the prefix is 16, leaving **138** for the payload. Work out the worst case on
  paper and confirm it; if `ngpc_qr_encode()` is given too much text it just returns 0 and draws
  nothing.

### Rules

- **Fixed-width fields.** Zero-padded decimal digits, or exactly N characters. No delimiters, no
  variable-length fields. The page slices the payload by offset. (One exception shipped: a trailing
  variable-length list whose own count field comes first — e.g. Bowling's rolls.)
- **Characters: `0-9` and `A-Z` only** — plus at most `-` or `.` if you truly need a separator.
  **Never emit a space, `%` or `/`.** The site splits on `/`, trims whitespace and runs
  `decodeURIComponent`, so those characters silently corrupt data: a `/` splits your payload, a
  trailing space is trimmed away, a bare `%` throws an error. (This bit two shipped games when they
  used all 45 QR alphanumeric characters as a number base — use base-36 digits `0-9A-Z` instead.)
  Anything outside the QR alphanumeric set makes `ngpc_qr_encode()` return 0.
- **Send raw inputs, not totals the site can recompute.** Bowling sends every roll and the site
  replays the scoring; Yahtzee sends 13 category scores and the site adds the bonus and total. The
  site can then reject impossible results and show a full scorecard for free.
- **Add a checksum if rankings matter.** A QR is just text a phone shows — anyone can build one. A
  short keyed CRC (a salt only the firmware and the site know, encoded as 2–4 base-36 digits) stops
  casual forging; Bowling's and Sokoban's payloads are examples. A checksum is integrity, not proof
  of honest play.
- **Plan for change.** Put a one-character format-version field in if you might extend the payload
  later; the site can then accept both versions.

---

## Step 4 — Build the payload in code

`src/example_qr_submit.c` has a complete, compiled example (`qr_build_payload`, `qr_append_dec`).
Things that matter on this toolchain (cc900):

- **No `/` or `%` on `u16` for digit extraction.** Some shapes miscompile. Use repeated subtraction
  against a table of powers of ten, as the example does.
- **Widen before you add or multiply.** A `u8` runtime value plus/times a constant silently wraps at
  255. Cast to `u16` first. Same for `u8 << 8` — it reads back 0 without a `(u16)` cast.
- **Statics in big non-leaf functions.** A non-leaf function with many locals can compile to a broken
  prologue; the renderer and example keep their working variables `static` for that reason.
- **Include `carthdr.h` at the top of your main file**, before any code or data. Included in the
  middle it can leave following code in the wrong section and the ROM resets in a loop (the watchdog
  fires). `tests/qr_smoke_main.c` shows the right order.

---

## Step 5 — Draw the code

```c
static NgpcQr s_qr;                       /* static: no heap, ~230 bytes of RAM */

if (ngpc_qr_encode(&s_qr, text)) {        /* 1 on success, 0 on bad/too-long text */
    ngpc_qr_pixel_draw(&s_qr, GFX_SCR2, 132u, 6u, NGPC_QR_PIXEL_SCALE, 12u, 8u);
}
```

`ngpc_qr_pixel_draw(qr, plane, tile_base, palette, scale, x, y)`:

| Argument | Meaning |
|---|---|
| `plane` | `GFX_SCR1` or `GFX_SCR2`. Use SCR2 so SCR1 keeps your text. |
| `tile_base` | First of `ngpc_qr_pixel_tiles(x, y, scale)` consecutive **free tile slots** — they are overwritten (306 for the standard layout). Use ≥ 128 so the BIOS font in tiles 32–127 survives. |
| `palette` | 0–15. Set by the call: index 1 white, index 2 black, index 0 transparent. Pick one your screen doesn't otherwise use. |
| `scale` | Pixels per module. **3** (`NGPC_QR_PIXEL_SCALE`) for profile 5. |
| `x`, `y` | Top-left pixel of the code including its quiet zone. |

The standard layout: scale 3 plus the 4-module quiet zone = 45 × 3 = **135 px square**, centred at
`x = 12`, `y = 8`, which leaves text rows 0 and 18 free for the banner
(`HTTPS://NGPC-DEV.COM` / `SCAN TO SUBMIT SCORE`). It returns 0 *before* touching VRAM if anything is
out of range.

### The two ordering rules

1. **Encode first, draw second.** Calling `ngpc_qr_encode()` after any pixel/tile drawing in the same
   tick can produce a blank matrix. Encode everything you need, *then* draw. (Root cause not found;
   the ordering is a reliable workaround.)
2. **Defer the encode one frame.** It takes over a second. If you print "GENERATING…" and encode in
   the same frame, the text never reaches the screen and the display just freezes. Print on one
   frame, encode+draw on the next.

### Leaving the screen

The code claimed tiles and rewrote SCR2's map cells. On the way out call `ngpc_gfx_clear(GFX_SCR2)`
**and then** reload your own tile art. Reloading art alone is not enough — the old map cells still
point at those tiles and show your art as garbled fragments. (This was a real bug in Farkle.)

### Colour and backdrop

Transparent pixels (index 0) show the backdrop. The example sets the backdrop black so the code
square is white-on-black-surrounded; if you want white all round, set the backdrop white instead.
Don't leave sprites on screen: a sprite showing through the white quiet zone can ruin a scan — hide
them off-screen (priority 0 alone is not reliable against a see-through background).

### Other profiles

`src/ngpc_qr_config.h` selects the profile at compile time (`-DNGPC_QR_PROFILE=n`; compile *every*
file that includes it with the same value):

| Profile | Version | Modules | Max text | Notes |
|---|---|---|---|---|
| 2 | V2-M | 25 | 38 | smaller/faster, little room |
| 3 | V3-L | 29 | 77 | |
| 4 | V4-L | 33 | 114 | thin 2-module quiet zone |
| **5** | **V5-L** | **37** | **154** | **default; what the newest games use** |

Only profile 5 is verified in this package (smoke test + example, decoded from emulator
screenshots; the same renderer ran on real hardware in Bowling and Carcassonne2). Use 5 unless you
have a reason not to.

---

## Step 6 — The entry and show screens (house style)

You can lay out your own screens, but every game on the site uses the same flow so players learn it
once. If you want to match it:

**Entry screen** (tile column, row; the screen is 20×19):

| Element | Position |
|---|---|
| Title `LEADERBOARD ENTRY` | (1, 1) |
| Stat label (`SCORE:`, `TIME:` …) | (2, 3) |
| Stat value | (9, 3) |
| 3 initials | row 5, columns 3 / 5 / 7 |
| `^` cursor under the selected letter | row 6 |
| Hints | (1,9) `UP/DOWN: LETTER` · (1,10) `L/R: MOVE` · (1,11) `OPT: QR   B: BACK` · (1,12) `HOLD A: FAST SCROLL` |

**Controls:** OPTION builds the payload and goes straight to the show screen (no confirm prompt);
B steps back one screen, keeping the letters; A only matters as the fast-scroll modifier.

**Show screen:** the code as in Step 5, banner on rows 0 and 18, and "GENERATING…" at (5, 9) on the
frame before the encode.

Start the initials at a saved default if you can (Bowling and Minesweeper keep one in flash,
set from an OPTIONS screen) so players don't retype them every game.

---

## Step 7 — Test properly

1. **Many payloads, not one.** Encode your worst case, your typical case and several random ones.
   Decode each emulator screenshot and compare byte for byte (`tests/decode_screenshot.py`).
2. **Use 250+ frames** before the screenshot. A blank or white code at 30 frames is just the encode
   still running.
3. **Real hardware and a real phone.** An emulator screenshot can look perfect and still fail to scan
   on a real screen. Photograph the real console screen from a normal distance and decode the photo.
   Try bright light and low light.
4. **Run the site's own parsing** over your generated payloads if you can (ask the site owner for the
   page's `parsePayload`): a payload that decodes fine can still be mangled by the site's URL
   handling — that is how the space/`%`/`/` rules were found.
5. Check the watchdog: run the emulator with hardware-safety checks on. The encode is long but your
   code must keep the console responsive (interrupts running) the whole time.

### If something goes wrong

| Symptom | Likely cause |
|---|---|
| Blank/white code | Too few frames before screenshot; or encoded after drawing in the same tick. |
| Encode returns 0 | Text too long (> 154), or contains a character outside `0-9 A-Z space $ % * + - . / :`. |
| ROM resets in a loop (watchdog) | `carthdr.h` not included at the top of the file; or a long loop with interrupts disabled. |
| Game art garbled after leaving | Forgot `ngpc_gfx_clear(GFX_SCR2)` before reloading tiles. |
| Text banner invisible/black | Wrong palette for the text plane. |
| Scans in emulator but not on a phone | Code too small/blurry; keep scale 3 and the full quiet zone; hide sprites. |
| Site shows wrong value in last field | Payload ended in a space (trimmed) or contained `/` or `%`. |

---

## Step 8 — Send your spec to the site owner

When the payload is final and tested, fill in `SUBMISSION_TEMPLATE.md` — or copy
`submission-template.json`, fill it in, and use **Import from file** on https://www.ngpc-dev.com/dev/submit/
— and send it with your ROM and a 160×152 title-screen PNG. Include several real example payload
strings. The site owner builds the leaderboard page, validation rules and scorecard from it.

---

## Migrating from v1

v1 was the Version-3, 5 px/module, bare-payload SDK. In v2:

- **API:** `ngpc_qr_encode(const char *text, u8 *grid)` is now `ngpc_qr_encode(NgpcQr *qr, const char *text)`
  returning 1 on success; modules are read with `ngpc_qr_get_module(qr, x, y)`.
- **Rendering:** the `ngpc_bitmap.h`-based `qr_show_screen()` loop is replaced by `ngpc_qr_pixel_draw()`.
  The old `QR_MODULE_PX 5` rule applied to V3 codes; v2 codes are denser (3 px/module) but bigger
  in capacity and were verified on real hardware.
- **Capacity:** 154 characters instead of 77.
- **URL prefix:** payloads now carry `NGPC-DEV.COM/<CODE>/` so a phone camera opens the site directly.
  v1 told you to send a bare payload; that is no longer the convention.
- **Checksums:** no `/`, `%`, space — see Step 3.

---

*Source files are MIT-licensed. The encoder's tables were generated from Nayuki's MIT QR reference
implementation. Note: the header comment in `ngpc_qr.c` still says "V2-M or V3-L"; the file is
unchanged from the shipped games so it can be diffed against theirs, and the profile table above is
the accurate description.*
