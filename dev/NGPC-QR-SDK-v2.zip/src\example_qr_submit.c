/*
 * example_qr_submit.c - worked example of the leaderboard QR flow: build a payload, encode it,
 * draw the code, print the banner. The pieces are lifted from the shipped, hardware-verified code
 * in Neo Bowling / Carcassonne2 (profile 5, 3 px per module). Not a drop-in file -- copy what you
 * need into your game and swap the fields for your own scoring data. INTEGRATION_GUIDE.md walks
 * through it step by step.
 *
 * Needs from your project (all part of NgpCraft_base_template): ngpc_hw.h, ngpc_gfx.h, ngpc_text.h,
 * ngpc_timing.h. Needs from this SDK (put these in src/core/): ngpc_qr.c/.h, ngpc_qr_config.h,
 * ngpc_qr_tables.h, ngpc_qr_pixel.c/.h -- and add ngpc_qr.rel + ngpc_qr_pixel.rel to the Makefile's
 * OBJS list (plus header dependency lines, see the guide).
 */
#include "ngpc_types.h"
#include "ngpc_hw.h"
#include "ngpc_gfx.h"
#include "ngpc_text.h"
#include "ngpc_qr.h"
#include "ngpc_qr_pixel.h"

/* ---- 1. Your game code (2-6 characters, digits and A-Z) --------------------------------------
 * Must not equal or prefix/extend a code already on the leaderboard (BW TT YZ FK 2K GD SD XN OV MS
 * BK CA ...). Ask the site owner if unsure. Lowercased, it is also the folder of your leaderboard
 * page: /xx/. */
#define QR_GAME_CODE   "XX"

/* The text the QR carries is URL_PREFIX + payload. A phone's own camera app opens the URL, and the
 * site's router sends the scan to your leaderboard page with the payload intact.
 *   NGPC-DEV.COM/XX/XXAAA00123045
 *   '-------------''-' payload starts with the game code again
 * Uppercase on purpose: QR alphanumeric mode has no lowercase, and a smaller code scans better. */
#define QR_URL_PREFIX  "NGPC-DEV.COM/" QR_GAME_CODE "/"

/* ---- 2. The payload ---------------------------------------------------------------------------
 * <game code 2><initials 3><score 5 digits><level 3 digits> = 13 characters. Rules:
 *   - every field FIXED width (zero-padded digits, or exactly N letters). No separators.
 *   - characters: 0-9 and A-Z only (plus '-' or '.' if you really must). NEVER ' ', '%' or '/':
 *     the site's URL handling mangles them (split on '/', trim, decodeURIComponent).
 *   - send RAW inputs, not totals the site can recompute (see the guide).
 *   - URL_PREFIX + payload must be <= NGPC_QR_TEXT_MAX (154) characters in the worst case.
 */
static char s_qr_payload[NGPC_QR_TEXT_MAX + 1u];

/* `width` zero-padded decimal digits (1..5) appended at out[*pos], advancing *pos. Repeated
 * subtraction, NOT divide/modulo: cc900 miscompiles u16 / and % by small constants in some shapes. */
static const u16 s_pow10[5] = { 10000u, 1000u, 100u, 10u, 1u };
static void qr_append_dec(char *out, u8 *pos, u16 value, u8 width)
{
    u8 i;
    u16 c;
    for (i = (u8)(5u - width); i < 5u; i++) {
        c = 0u;
        while (value >= s_pow10[i]) { value = (u16)(value - s_pow10[i]); c++; }
        out[(*pos)++] = (char)('0' + c);
    }
}

/* Writes URL_PREFIX + payload into out (NUL-terminated); out must hold NGPC_QR_TEXT_MAX + 1. */
static void qr_build_payload(char *out, const char initials[3], u16 score, u16 level)
{
    u8 pos = 0u;
    u8 i;
    for (i = 0u; QR_URL_PREFIX[i] != '\0'; i++) out[pos++] = QR_URL_PREFIX[i];
    out[pos++] = QR_GAME_CODE[0];
    out[pos++] = QR_GAME_CODE[1];
    out[pos++] = initials[0];
    out[pos++] = initials[1];
    out[pos++] = initials[2];
    qr_append_dec(out, &pos, score, 5u);
    qr_append_dec(out, &pos, level, 3u);
    out[pos] = '\0';
}

/* ---- 3. Show the code -------------------------------------------------------------------------
 * One NgpcQr for the whole game (static: no heap, ~230 bytes). Layout for the full-size code:
 *   - scale 3 + the standard 4-module quiet zone = (37 + 8) * 3 = 135 px square
 *   - centred: x = (160 - 135) / 2 = 12; y = 8 leaves text rows 0 and 18 free for the banner
 *   - tiles QR_TILE_BASE.. are CLAIMED (ngpc_qr_pixel_tiles() of them, 306 here); pick a base >= 128
 *     so the BIOS font in tiles 32-127 survives, and reload your own art there when you leave.
 * The code goes on SCR2 so SCR1 keeps your text; use a palette your screen isn't otherwise using. */
#define QR_TILE_BASE   132u
#define QR_PAL           6u    /* a free SCR2 palette */
#define QR_TEXT_PAL      0u    /* an SCR1 palette your font already uses */
#define QR_X            12u
#define QR_Y             8u

static NgpcQr s_qr;

static void qr_show(const char initials[3], u16 score, u16 level)
{
    ngpc_gfx_clear(GFX_SCR1);
    ngpc_gfx_clear(GFX_SCR2);
    ngpc_gfx_set_bg_color(0x0000u);   /* black behind the code; the banner text is white on it */

    qr_build_payload(s_qr_payload, initials, score, level);

    /* ENCODE FIRST, THEN DRAW. Encoding after any pixel/tile drawing in the same tick can come out
     * blank; encode everything you need, then draw. The encode itself is slow (~1-2 s of real
     * time): print "GENERATING..." on an earlier frame and call this on the next one, otherwise
     * the text never reaches the screen before the display freezes. */
    if (ngpc_qr_encode(&s_qr, s_qr_payload)) {
        ngpc_qr_pixel_draw(&s_qr, GFX_SCR2, QR_TILE_BASE, QR_PAL,
                           NGPC_QR_PIXEL_SCALE, QR_X, QR_Y);
    }
    ngpc_text_print(GFX_SCR1, QR_TEXT_PAL, 0u, 0u, "HTTPS://NGPC-DEV.COM");
    ngpc_text_print(GFX_SCR1, QR_TEXT_PAL, 0u, 18u, "SCAN TO SUBMIT SCORE");
}

/* ---- 4. Leaving the screen --------------------------------------------------------------------
 * The code claimed tiles QR_TILE_BASE.. and rewrote SCR2's map cells. On the way out:
 *     ngpc_gfx_clear(GFX_SCR2);      // drop the map cells that still point at the QR tiles
 *     reload_my_game_tiles();        // restore whatever art lived in those tile slots
 * Reloading art alone is not enough: the old map cells would show it as garbage fragments. */
