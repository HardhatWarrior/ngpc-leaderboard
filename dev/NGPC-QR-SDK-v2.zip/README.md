# NGPC Leaderboard QR SDK — v2 (profile 5, 154 characters, pixel mode)

Add an on-screen QR code to your Neo Geo Pocket Color game so players can scan it with a phone and
submit their score to https://www.ngpc-dev.com — no web development needed on your side.

**Start with [`INTEGRATION_GUIDE.md`](INTEGRATION_GUIDE.md).** In short:

1. Copy `src/ngpc_qr*.{c,h}` into your project and add two objects to the Makefile.
2. Run `tests/qr_smoke_main.c` as a throwaway ROM and decode its screen — proves your setup in minutes.
3. Pick a game code, design a fixed-width payload, build it as `NGPC-DEV.COM/<CODE>/<payload>`.
4. `ngpc_qr_encode()` then `ngpc_qr_pixel_draw()` — encode first, draw second.
5. Test on a real console with a real phone.
6. Fill in `SUBMISSION_TEMPLATE.md` (or `submission-template.json`) and send it to the site owner.

## What changed from v1

| | v1 | **v2** |
|---|---|---|
| QR version | V3-L, 29 modules | **V5-L, 37 modules** |
| Capacity | 77 characters | **154 characters** |
| Rendering | `ngpc_bitmap.h` fill-rect loop, 5 px/module | **`ngpc_qr_pixel_draw()`**, 3 px/module, straight to tile RAM |
| Encoder API | `ngpc_qr_encode(text, grid)` | `ngpc_qr_encode(&qr, text)` + `ngpc_qr_get_module()` |
| QR text | bare payload | **`NGPC-DEV.COM/<CODE>/<payload>`** (phone camera opens the site) |
| Encoder speed | per-term GF multiply (about a quarter of encode time) | log-domain ECC, no multiply call per term |

v1 code will not compile against v2 — see the migration section of the guide.

## Verified

- `ngpc_qr.c`/`.h` are byte-identical to Neo Bowling's current files; the config and tables are byte-identical to Carcassonne2's (Bowling's encoder additionally carries a compiler-bug workaround and the faster ECC loop).
- Compiled with the official Toshiba toolchain (cc900) inside a copy of a real game project; linked
  and ran on the native emulator core with silicon timing, **no hardware-safety faults**.
- `tests/qr_smoke_main.c` (a worst-case 154-character code) and the worked example both decode with an
  independent decoder (zbar) from the emulator screenshot, **byte for byte**; the references are in `tests/`.
- Not part of this package's own testing: a real console and real phone. The same renderer design
  runs on real hardware in Bowling and Carcassonne2 — please run Step 7 of the guide on yours.

## License

MIT, as stated in each source file's header. The encoder's lookup tables were generated from Nayuki's MIT-licensed QR Code reference
implementation.
