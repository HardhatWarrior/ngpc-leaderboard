# Leaderboard Submission Spec

Fill this in once your on-device QR payload is final and tested (see `INTEGRATION_GUIDE.md`), and send
it to the leaderboard site owner with your ROM and title screenshot. It is everything needed to build
your leaderboard page, validation rules and scorecard — no back-and-forth if every section is complete.

**Shortcut:** copy `submission-template.json`, fill it in, and use **Import from file** on
https://www.ngpc-dev.com/dev/submit/ — it loads the same information straight into the submission form.
(The ROM and screenshots are still attached in the form itself.)

---

## 1. Game identity

- **Game name** (as shown on the leaderboard, e.g. "Neo Bowling"):
- **Game code, 2–6 characters** (digits and A–Z). Must not equal, prefix or extend a claimed code:
  `2K BK BW CA DDMR FK FU GD HGS MS OV RD RVNG SD SK TT XN YZ`
- **Title screen screenshot:** a PNG from a real emulator/hardware run at the title screen (160×152,
  no upscaling). Up to two extra screenshots/GIFs are optional.

## 2. Payload format

The QR text is `NGPC-DEV.COM/<CODE>/<payload>`. This table describes the **payload only** (it starts
with your game code). Real example (Farkle, 2-character code `FK`):

| Offset | Width | Field | Format | Notes |
|---|---|---|---|---|
| 0 | 2 | Game code | `FK` | constant |
| 2 | 3 | Initials | `A-Z` ×3 | player-entered |
| 5 | 5 | Score | zero-padded decimal | 0–65535 |
| 10 | 3 | Rounds | zero-padded decimal | turns taken |
| 13 | 3 | Opened | zero-padded decimal | round first banked ≥ 750, 0 = never |
| 16 | 3 | Farkles | zero-padded decimal | bust count |
| 19 | 1 | Result | `1`/`W`/`L`/`D` | `1` = solo, else VS Link outcome |

**Total payload length (excluding the `NGPC-DEV.COM/XX/` prefix):** (must be ≤ 154 − prefix length;
138 for a 2-character code)

Your table:

| Offset | Width | Field | Format | Notes |
|---|---|---|---|---|
| | | | | |

Remember: every field fixed width, characters `0-9 A-Z` only (at most `-` or `.`), **never space, `%`
or `/`**, raw inputs rather than totals the site can recompute.

## 3. Field bounds (for database validation)

For every field give the real minimum and maximum it can hold. This becomes the server-side rule that
rejects malformed or forged submissions: too loose is a security gap, too tight rejects real scores.

| Field | Min | Max |
|---|---|---|
| | | |

## 4. What wins

- Which single field do leaderboard rows sort by? (Use the plain name of one payload field, e.g.
  `score` or `time`. Put any tie-break rules in section 5 or 7.)
- Higher is better, or lower is better (e.g. a time)?

## 5. Scorecard detail view

If your payload carries raw inputs rather than a total, give the exact formula or algorithm to rebuild
the full scorecard (pseudocode is fine), the way the site derives Bowling's frames from the roll history.
If you add a checksum, describe it fully (algorithm, which bytes it covers, where the salt lives — send
the salt separately and privately).

## 6. Example payloads

3–5 real payloads from real or realistic play, copied exactly as the phone reads them (including the
`NGPC-DEV.COM/XX/` prefix): a typical result, a best case, and a multiplayer result if you have one.

```
(example payloads)
```

## 7. Anything else

Multiple modes with different payload shapes, optional fields, non-numeric fields, anything the
other sections don't cover. When in doubt, over-explain.
